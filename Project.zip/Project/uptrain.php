<?php include('Server.php') ?>
<?php


if(isset($_POST['upd-btn']))
{
    $TrainID=$_SESSION["TrainID"];
    $name=mysqli_real_escape_string($con,$_POST['tname']);
    $type=mysqli_real_escape_string($con,$_POST['ttype']);
    $seats=mysqli_real_escape_string($con,$_POST['seats']);
    
    $sql="UPDATE train SET  name='$name',
    type ='$type',
    no_seats='$seats'
    WHERE TrainID='$TrainID' ";

    if(mysqli_query($con,$sql))
    {
        header('location: admin.html');
    }
    else 
    {
        echo("not done");
    }
}
?>