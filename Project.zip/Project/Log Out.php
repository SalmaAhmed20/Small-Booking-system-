<?php
    session_destroy();
    header("location: First Page.html");
?>
